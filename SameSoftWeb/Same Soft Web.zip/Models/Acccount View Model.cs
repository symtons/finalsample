﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SameSoftWeb.Models
{
    public class Acccount_View_Model
    {
    }
}